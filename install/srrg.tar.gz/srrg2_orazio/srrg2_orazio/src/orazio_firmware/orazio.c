#include <assert.h>
#include <string.h>
#include <math.h>
#include "timer.h"
#include "eeprom.h"
#include "encoder.h"
#include "digio.h"
#include "sonar.h"
#include "pwm.h"
#include "adc.h"

#include "orazio_globals.h"
#include "orazio_param.h"
#include "orazio_comm.h"
#include "orazio_pwm.h"
#include "orazio_imu.h"
#include "orazio_joints.h"
#include "orazio_drive.h"
#include "orazio_sonar.h"
#include "orazio_watchdog.h"
#include <stdio.h>

// used to handle communication
volatile uint8_t tick_counter;           //incremented at each timer tick, reset on comm
volatile uint8_t comm_handle=0;
// this is to remember how many packets we received since the last update

void onTimerTick(void* args __attribute__((unused))){
  Orazio_jointsHandle();
  // read the battery voltage

#ifdef _ARDUINO_MEGA_2560_
  system_status.battery_level=ADC_getValue(4);
#endif

  --tick_counter;
  if (!tick_counter){
    tick_counter=system_params.comm_cycles;
    comm_handle=1;
  }
#ifdef _ARDUINO_MEGA_2560_
  ADC_start();
#endif
}


int main(int argc, char** argv){
  // initialize global variables
  Orazio_globalsInit();
  Orazio_jointsPreInit();

  // initialize devices
  EEPROM_init();
  DigIO_init();
  PWM_init();
  Encoder_init();
  Timers_init();
#ifdef _ORAZIO_USE_SONAR_
  Sonar_init();
#endif

  // initialize subsystems
  Orazio_paramInit();
  Orazio_jointsInit();
  Orazio_driveInit();
  Orazio_servoInit();
  Orazio_imuInit();
#ifdef _ORAZIO_USE_SONAR_
  Orazio_sonarInit();
#endif
  
  Orazio_commInit();
  //start a timer
  struct Timer* timer=Timer_create("timer_0",system_params.timer_period_ms,onTimerTick,0);
  Timer_start(timer);

  // we want to get the first data whe the platform starts
  tick_counter=system_params.comm_cycles;
  system_status.watchdog_count=system_params.watchdog_cycles;

  // loop foreva
  // remember how many packets you received before;
  
  Orazio_commSendString("Ready");
  while(1){
    ++system_status.idle_cycles; // count how long we spend doing nofin
    if (comm_handle){
      // we sample from ADC;
      uint16_t previous_rx_packets=system_status.rx_packets;
      Orazio_driveHandle();
      Orazio_servoHandle();
      Orazio_imuHandle();
#ifdef _ORAZIO_USE_SONAR_
      Orazio_sonarHandle();
#endif
      Orazio_commHandle();
      if (previous_rx_packets!=system_status.rx_packets)
        Orazio_watchdogReset();
      Orazio_watchdogHandle();
      comm_handle=0;
      system_status.idle_cycles=0;
    }
  }
}
