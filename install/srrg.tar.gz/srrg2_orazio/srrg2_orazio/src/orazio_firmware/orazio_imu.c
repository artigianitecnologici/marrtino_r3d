#include "orazio_imu.h"

void Orazio_imuInit(void){
}

void Orazio_imuControl(void){
}

void Orazio_imuHandle(void){
  if (! imu_params.header.system_enabled)
    return;
}
